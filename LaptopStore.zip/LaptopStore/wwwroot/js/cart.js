﻿// تحديث الكمية
document.querySelectorAll('.quantity-btn').forEach(btn => {
    btn.addEventListener('click', async function () {
        const input = this.parentElement.querySelector('input');
        let quantity = parseInt(input.value);

        if (this.textContent === '+') {
            quantity++;
        } else if (quantity > 1) {
            quantity--;
        }

        input.value = quantity;

        // إرسال طلب AJAX للتحديث
        const productId = this.closest('[data-product-id]').dataset.productId;
        await fetch('/Account/UpdateCart', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'RequestVerificationToken': document.querySelector('input[name="__RequestVerificationToken"]').value
            },
            body: JSON.stringify({ productId, quantity })
        });
    });
});

// إفراغ السلة
document.getElementById('clear-cart-btn').addEventListener('click', async function () {
    await fetch('/Account/ClearCart', {
        method: 'POST',
        headers: {
            'RequestVerificationToken': document.querySelector('input[name="__RequestVerificationToken"]').value
        }
    });
    location.reload();
});